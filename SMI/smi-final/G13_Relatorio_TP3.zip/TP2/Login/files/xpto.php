<?php
    $myVar = "xpto";
?>