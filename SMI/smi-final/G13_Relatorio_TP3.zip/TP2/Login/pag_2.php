<?php

include( "ensureAuth.php" );
include( "header.php" );
?>

<p>Contents of page 2</p>

<?php

include( "session.inc" );
?>

<?php

include( "footer.php" );
?>