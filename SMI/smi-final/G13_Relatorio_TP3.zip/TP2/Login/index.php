<!DOCTYPE html>
<?php
  include_once( "../config.php" );
?>
<html>
    <head>
        <meta http-equiv='Content-Type' content='text/html; charset=utf-8'>
        <title>Authentication Using PHP</title>

        <link 
          rel="stylesheet" 
          type="text/css" 
          href="../../<?php echo $pathExampleRSS;?>/styles/rss.css">
    </head>

    <body>
        <h1>PHP - Sessions</h1>

        <p align="center"><a href="formLogin.php">login</a></p>
    </body>
</html>