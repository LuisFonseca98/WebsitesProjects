<p>Foi enviado um email para alterar a sua password</p>

<?php
require_once( "../Lib/lib.php" );
require_once( "../Lib/db.php" );

if (!isset($_SESSION)) {
    session_start();
}

dbConnect(ConfigFile);
$dataBaseName = $GLOBALS['configDataBase']->db;
$serverName = $_SERVER[ 'SERVER_NAME' ];
#$serverName = "localhost";

$serverPort = 80;

$name = webAppName();

$baseUrl = "http://" . $serverName . ":" . $serverPort;

$baseNextUrl = $baseUrl . $name;
mysqli_select_db( $GLOBALS['ligacao'], $dataBaseName );


$query = "SELECT `id` FROM `$dataBaseName` . `auth-basic` WHERE `email`= '".$_POST['email']."'"; 
    $idUser = 0;
    $queryResult = mysqli_query( $GLOBALS['ligacao'], $query );
    if ($queryResult) {
        while ($registo = mysqli_fetch_array( $queryResult )){
           $idUser = $registo['id'];
        }         
    } 
    
    
    
    include './challenge.php';
    $query = "INSERT INTO `confirm_pass`(`id`,`challenge`) VALUES('".$idUser."', '".$challenge."')"; 
    mysqli_query($GLOBALS['ligacao'], $query);
    $_SESSION['passID'] = $idUser;
    include './confirmNewPassword.php';
    dbDisconnect();    
?>
