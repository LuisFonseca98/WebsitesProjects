<?php

$length = 10;    
$challenge = substr(str_shuffle('0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ'),1,$length);
$_SESSION['$challenge'] = $challenge;
?>
