<?php
    require_once( "../Lib/lib.php");
    require_once( "../Lib/lib-mail-v2.php" );
    require_once( "../Lib/HtmlMimeMail-class.php" );
    require_once( "../Lib/db.php" );
    
    $Account = 1;
    $ToName = "";
    $Subject = "Validar conta";
    $project = explode('/', $_SERVER['REQUEST_URI'])[2];
    $Message = "Clique no link abaixo para alterar a sua palavra pass." .  
            "http://localhost/examples-smi/".$project."/Login/updateUserInfo.php?challenge=".$_SESSION['$challenge'] . "&id=".$_SESSION['passID'];  
    $smtpServer = "smtp.gmail.com";
    $mail = new HtmlMimeMail();
    $query = "SELECT `email` FROM `$dataBaseName` . `auth-basic` WHERE `id`= '".$_SESSION['passID']."'"; 
    
    $Email = 0;
    $queryResult = mysqli_query( $GLOBALS['ligacao'], $query );
    if ($queryResult) {
        while ($registo = mysqli_fetch_array( $queryResult )){
           $Email = $registo['email'];
        }         
    }

    /*
     * HTML component of the e-mail
     */
$MessageHTML = <<<EOD
<html>
    <body style="background: url('background.gif') repeat;">
        <font face="Verdana, Arial" color="#FF0000">
            $Message
        </font>
    </body>
</html>
EOD;
    /*
     * Add the text, html and embedded images.
     */
    $mail->add_html( $MessageHTML, $Message);

    /*
     * Builds the message.
     */
    $mail->build_message();

    /*
     * Sends the message.
     */
    $result = $mail->send(
          $smtpServer,
          1,
          465,
          "iselg13smi@gmail.com",
          "isel1920",
          $ToName, 
          $Email,
          "G13-SMI", 
          "iselg13smi@gmail.com",
          $Subject,
          "X-Mailer: Html Mime Mail Class");
    
    
?>
