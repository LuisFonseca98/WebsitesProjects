<?php
if (!isset($_SESSION)) {
    session_start();
}
$_SESSION['passID'] = $_GET['id']; 
?>

<head>
  <link rel="stylesheet" type="text/css" href="CSS/login.css">
  <title>Update User Info</title>
</head>

<ul>
    <li><a href="../Conteudos/paginaConteudos/conteudosWebsiteCursos.php">Cursos</a></li>
    <li><a href="../About/about.php">About</a></li>
    <li><a href="../PaginaPrincipal/PaginaPrincipal.php">Home</a></li>
</ul>

<div class="cont">
    <form action="./processUpdateUserInfo.php" method="POST">
    <label><b>Nova Pass:</b></label>
    <input type="password" placeholder="password" name="password" required>
    <br>
    <button type="submit">Alterar</button>
</form>
</div>