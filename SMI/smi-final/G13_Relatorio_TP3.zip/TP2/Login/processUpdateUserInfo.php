<?php

if (!isset($_SESSION)) {
    session_start();
}

require_once( "../Lib/lib.php" );
require_once( "../Lib/db.php" );


dbConnect(ConfigFile);
$dataBaseName = $GLOBALS['configDataBase']->db;
mysqli_select_db( $GLOBALS['ligacao'], $dataBaseName );  

// PASSWORD ERROR      
$password1 = $_POST['password'];
$password2 = $_POST['password2'];
$passError = "";  
if($password1 != $password2){
  $passError = "" . '<p>' . "Passwords não correspondem" . '</p>';  
} 
  

if (isset($_POST['password'])) {  
    $queryPassword = "UPDATE `auth-basic` SET `password`= '". $_POST['password'] ."' WHERE `id`='".$_SESSION['passID']."'";
    $queryResultPassword = mysqli_query( $GLOBALS['ligacao'], $queryPassword );
}

$serverName = "localhost";
$serverPort = 80;
$name = webAppName();
$baseUrl = "http://" . $serverName . ":" . $serverPort;
$baseNextUrl = $baseUrl . $name;
$nextUrl = "messageNewPasswordChanged.php";

echo $queryPassword;

header("Location: " . $baseNextUrl . $nextUrl);

?>