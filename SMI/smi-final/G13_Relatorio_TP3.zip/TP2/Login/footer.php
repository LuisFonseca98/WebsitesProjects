<hr>
<a href="pag_1.php">Page 1</a>
<a href="pag_2.php">Page 2</a>
<a href="pag_3.php">Page 3</a>
<a href="logout.php">Logout</a>