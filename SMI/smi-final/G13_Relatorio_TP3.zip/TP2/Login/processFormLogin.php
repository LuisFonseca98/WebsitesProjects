<?php

require_once( "../Lib/lib.php" );
require_once( "../Lib/db.php" );

if (!isset($_SESSION)) {
    session_start();
}

$serverName = $_SERVER['SERVER_NAME'];
#$serverName = "localhost";

$serverPort = 80;

$name = webAppName();

$baseUrl = "http://" . $serverName . ":" . $serverPort;

$baseNextUrl = $baseUrl . $name;

$username = $_POST['username'];
$password = $_POST['password'];

$userId = isValid($username, $password, "basic");
if ($userId > 0) {
    $_SESSION['username'] = $username;
    $_SESSION['id'] = $userId;
    if (isset($_SESSION['locationAfterAuth'])) {
        $baseNextUrl = $baseUrl;
        $nextUrl = $_SESSION['locationAfterAuth'];
        header("Location: " . "../Conteudos/paginaConteudos/conteudosWebsiteCursos.php");
    } else {
        header("Location: " . "../Conteudos/paginaConteudos/conteudosWebsiteCursos.php");
    }
} else {
    $_SESSION['loginMsg'] = "Email e Password não correspondem";
    $nextUrl = "formLogin.php";
    header("Location: " . $baseNextUrl . $nextUrl);
}
?>