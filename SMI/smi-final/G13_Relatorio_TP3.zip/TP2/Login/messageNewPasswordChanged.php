
<head>
  <link rel="stylesheet" type="text/css" href="CSS/login.css">
</head>

<ul>
    <li><a href="formLogin.php">Login</a></li>
    <li><a href="../Conteudos/paginaConteudos/conteudosWebsiteCursos.php">Cursos</a></li>
    <li><a href="../About/about.php">About</a></li>
    <li><a href="../PaginaPrincipal/PaginaPrincipal.php">Home</a></li>
</ul>

<br>
<br>
<p>A sua palavra pass foi alterada com sucesso. <br> Por favor volta à página de login para efetuar o novo registo</p>
