<div class="cont">
    <form action="./processSendEmail.php" method="POST">
    <label><b>Introduza o seu email</b></label>
    <input type="email" placeholder="email" name="email" required>
  <button type="submit">Alterar</button>
</form>
</div>
