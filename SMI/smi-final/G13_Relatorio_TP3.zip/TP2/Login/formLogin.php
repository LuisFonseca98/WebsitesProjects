<?php
require_once( "../Lib/lib.php" );

if (!isset($_SESSION)) {
    session_start();
}

$errorMsg = "";

if(isset($_SESSION['loginMsg'])){
    $errorMsg = $_SESSION['loginMsg'];
    $_SESSION['loginMsg'] = '';
}

$serverName = $_SERVER['SERVER_NAME'];
#$serverName = "localhost";

$serverPortSSL = 443;
$serverPort = 80;

$name = webAppName();

$nextUrl = "https://" . $serverName . ":" . $serverPortSSL . $name . "processFormLogin.php";
//$nextUrl = "http://" . $serverName . ":" . $serverPort . $name . "processFormLogin.php";



  $text = "";
  $link = "";
        
  if (isset($_SESSION['username']) ) {
    $text = "Logout";
    $link = "../Login/logout.php";
    }
    else{
        $text = "Login";
        $link = "../Login/processFormLogin.php";
    }
?>

<head>
    <link rel="stylesheet" type="text/css" href="CSS/login.css">
    <title>Login</title>

</head>

<link rel="stylesheet" href="cssMain/mainPage.css">



<ul>
<?php echo "<li><a href='".$link."'><span class='notranslate'>".$text."</span></a></li>" ?>
    <li><a href="../Conteudos/paginaConteudos/conteudosWebsiteCursos.php">Cursos</a></li>
    <li><a href="../About/about.php"><span class='notranslate'>About</span></a></li>
    <li><a href="../PaginaPrincipal/PaginaPrincipal.php"><span class='notranslate'>Home</span></a></li>
    <li class="li" <a id="translate"> <div id="google_translate_element"></div></a></li>
</ul>


<div class="cont">
    <h3>Login</h3>
    <form action="<?php echo $nextUrl ?>" method="POST">
        <table>
            <tr>
                <td>User Name</td>
                <td><input 
                    type="text" 
                    name="username"
                    placeholder="User name"></td>
            </tr>
            <tr>
                <td>Password</td>
                <td><input 
                    type="password" 
                    name="password"
                    placeholder="Password"></td>
            </tr>
        </table>

        <input type="submit" value="Login"> <input type="reset" value="Clear">
        <a href="../Register/formRegister.php">Register</a>
        <p><?php echo $errorMsg?></p>  
    </form>
    <a href ="sendEmail.php">Esqueceu-se da password? Clique neste link para editar a sua password!</a>
</div>    

<script type="text/javascript">
    function googleTranslateElementInit() { 
        new google.translate.TranslateElement({pageLanguage: 'pt', includedLanguages: 'en,es,fr,pt', 
            layout: google.translate.TranslateElement.InlineLayout.SIMPLE},'google_translate_element');
    }
</script>
<script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>