<?php

include( "ensureAuth.php" );
include( "header.php" );
?>

<p>Contents of page 1</p>

<?php
include( "./files/xpto.php" );
echo $myVar . "\n<br>";

include( "session.inc" );
?>

<?php

include( "footer.php" );
?>