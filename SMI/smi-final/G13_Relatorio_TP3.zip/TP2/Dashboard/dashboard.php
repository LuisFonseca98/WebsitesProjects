<?php

if (!isset($_SESSION)) {
    session_start();
}

  $text = "";
  $link = "";
        
  if (isset($_SESSION['username']) ) {
    $text = "Logout";
    $link = "../Login/logout.php";
    }
    else{
        $text = "Login";
        $link = "../Login/processFormLogin.php";
    }
?>
<link rel="stylesheet" href="cssMain/mainPage.css">
<head>
  <title>Admin Dashboard</title>
</head>

<ul>
    <?php echo "<li><a href='".$link."'>".$text."</a></li>" ?>;
    <li><a href="../Conteudos/paginaConteudos/conteudosWebsiteCursos.php">Cursos</a></li>
    <li><a href="../About/about.php">About</a></li>
    <li><a href="../PaginaPrincipal/PaginaPrincipal.php">Home</a></li>
</ul>

<h1 id="title">Admin Dashboard</h1>

<div class="cont">
<form action="./changeAccount.php" method="POST">
    <label><b>Email da Conta:</b></label>
    <input type="email" placeholder="Introduzir Email da Conta" name="email_conta" required>
    <br>
    <br>
    <label><b>Role a atribuir:    </b></label>
    <select name="role" id="cars">
        <option value="1">Admin</option>
        <option value="2">Simpatizante</option>
        <option value="3">Utilizador</option>
    </select>
  <button type="submit">Alterar</button>
</form>
</div>
