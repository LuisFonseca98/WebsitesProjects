<?php

if (!isset($_SESSION)) {session_start();}

require_once( "../Lib/lib.php" );
require_once( "../Lib/db.php" );

dbConnect(ConfigFile);
$dataBaseName = $GLOBALS['configDataBase']->db;
mysqli_select_db( $GLOBALS['ligacao'], $dataBaseName );  

$myfile = fopen("../Lib/Config/.htconfig.xml", "wb");

$text = '<?xml version="1.0" encoding="utf-8"?>'.PHP_EOL;
fwrite($myfile, $text);
$text = '<!DOCTYPE DataBase SYSTEM "./database.dtd">'.PHP_EOL;
fwrite($myfile, $text);
$text = '<Config xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"'
        . ' xsi:noNamespaceSchemaLocation="./htconfig.xsd">'.PHP_EOL;
fwrite($myfile, $text);
$text = '   <DataBase>'.PHP_EOL;
fwrite($myfile, $text);
$text = '       <host>'.$_POST['localhost'].'</host>'.PHP_EOL;
fwrite($myfile, $text);
$text = '       <port>'.$_POST['porto'].'</port>'.PHP_EOL;
fwrite($myfile, $text);
$text = '       <db>'.$_POST['db'].'</db>'.PHP_EOL;
fwrite($myfile, $text);
$text = '       <username>'.$_POST['username'].'</username>'.PHP_EOL;
fwrite($myfile, $text);
$text = '       <password>'.$_POST['pass'].'</password>'.PHP_EOL;
fwrite($myfile, $text);
$text = '   </DataBase>'.PHP_EOL;
fwrite($myfile, $text);
$text = '</Config>'.PHP_EOL;
fwrite($myfile, $text);

fclose($myfile);

 
$serverName = "localhost";
$serverPort = 80;
$name = webAppName();
$baseUrl = "http://" . $serverName . ":" . $serverPort;
$baseNextUrl = $baseUrl . $name;
$nextUrl = "changeDBaccess.php";

echo $baseNextUrl . $nextUrl;

header("Location: " . $baseNextUrl . $nextUrl);

?>
