<?php

if (!isset($_SESSION)) {
    session_start();
}

  $text = "";
  $link = "";
        
  if (isset($_SESSION['username']) ) {
    $text = "Logout";
    $link = "../Login/logout.php";
    }else{
        $text = "Login";
        $link = "../Login/processFormLogin.php";
    }
?>
<link rel="stylesheet" href="cssMain/mainPage.css">
<head>
  <title>Admin Dashboard</title>
</head>

<ul>
    <?php echo "<li><a href='".$link."'>".$text."</a></li>" ?>;
    <li><a href="../Conteudos/paginaConteudos/conteudosWebsiteCursos.php">Cursos</a></li>
    <li><a href="../About/about.php">About</a></li>
    <li><a href="../PaginaPrincipal/PaginaPrincipal.php">Home</a></li>
</ul>

<h1 id="title">Alterar Acesso da Base de dados</h1>

<div class="cont">
    <br><br>
    <form action="./processChangeDBaccess.php" method="POST">
    <label><b>LocalHost:</b></label>
    <input type="localhost" placeholder="Introduzir LocalHost" name="localhost" required>
    <br>
    <label><b>Porto:</b></label>
    <input type="porto" placeholder="Introduzir Porto" name="porto" required>
    <br>
    <label><b>Database:</b></label>
    <input type="db" placeholder="Introduzir Base Dados" name="db" required>
    <br>
    <label><b>Username:</b></label>
    <input type="username" placeholder="Introduzir Username" name="username" required>
    <br>
    <label><b>Password:</b></label>
    <input type="pass" placeholder="Introduzir Password" name="pass" required>
  <button type="submit">Alterar</button>
</form>
</div>
