<?php

if (!isset($_SESSION)) {
    session_start();
}

require_once( "../Lib/lib.php" );
require_once( "../Lib/db.php" );


dbConnect(ConfigFile);
$dataBaseName = $GLOBALS['configDataBase']->db;
mysqli_select_db( $GLOBALS['ligacao'], $dataBaseName );  

$query = "SELECT `id` FROM `$dataBaseName` . `auth-basic` where `email`= '" . $_POST['email_conta'] . "'";
$id = -1;
$queryResult = mysqli_query( $GLOBALS['ligacao'], $query );
if ($queryResult) {
    while ($registo = mysqli_fetch_array( $queryResult )){
            $id = $registo['id'];
        }         
}   

$query = "UPDATE `auth-permissions` SET role= '". $_POST['role'] ."' where id='".$id."'";
$queryResult = mysqli_query( $GLOBALS['ligacao'], $query );

$serverName = "localhost";
$serverPort = 80;
$name = webAppName();
$baseUrl = "http://" . $serverName . ":" . $serverPort;
$baseNextUrl = $baseUrl . $name;
$nextUrl = "dashboard.php";

echo $baseNextUrl . $nextUrl;

header("Location: " . $baseNextUrl . $nextUrl);

?>
