<?php

if (!isset($_SESSION)) {
    session_start();
}

if ( !isset($_SESSION['username']) ) {

    //$_SESSION['locationAfterAuth'] = $_SERVER['REQUEST_URI'];
    $_SESSION['locationAfterAuth'] = $_SERVER['REQUEST_URI'];
    
    header("Location: ../../Login/formLogin.php");
    exit;
}
?>