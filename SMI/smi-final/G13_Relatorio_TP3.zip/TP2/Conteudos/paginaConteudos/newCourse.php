<?php

if (!isset($_SESSION)) {
    session_start();
}

require_once( "../../Lib/lib.php" );
require_once( "../../Lib/db.php" );

dbConnect(ConfigFile);
$dataBaseName = $GLOBALS['configDataBase']->db;
mysqli_select_db( $GLOBALS['ligacao'], $dataBaseName );  

if (isset($_POST['nome_curso']) 
        && isset($_POST['duracao'])
        && isset($_POST['role']) && isset($_POST['tag'])) {

    $query = "INSERT INTO `curso`(`nome_curso`,`duracao`,`img`,`required_role`,`tag`,`video`, `visible`)"
            . " VALUES('".$_POST['nome_curso']."', '".$_POST['duracao']."', '".$_FILES['imageFile']['name']."', '".$_POST['role']."',"
            . "'".$_POST['tag']."', '".$_FILES['videoFile']['name']."' , '".$_POST['privacy']."')";
    mysqli_query($GLOBALS['ligacao'], $query);
}
dbDisconnect();
//

include_once './imageUpload.php';
include_once './videoUpload.php';

//
$serverName = "localhost";
$serverPort = 80;
$name = webAppName();
$baseUrl = "http://" . $serverName . ":" . $serverPort;
$baseNextUrl = $baseUrl . $name;
$nextUrl = $_SESSION['locationAfterAdd'];
header("Location: " . $baseNextUrl . $nextUrl);
?>

