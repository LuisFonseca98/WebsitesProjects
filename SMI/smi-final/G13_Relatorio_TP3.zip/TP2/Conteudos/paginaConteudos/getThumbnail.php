<?php
    require_once( "../../Lib/lib.php" );
    require_once( "../../Lib/db.php" );
    dbConnect(ConfigFile);
    $dataBaseName = $GLOBALS['configDataBase']->db;
    mysqli_select_db( $GLOBALS['ligacao'], $dataBaseName );  
    
    
    $query = "SELECT `img` FROM `$dataBaseName` . `curso` WHERE `id_curso` = " . $_GET['idC'];
    $img = "";
    $queryResult = mysqli_query( $GLOBALS['ligacao'], $query );

    
    if ($queryResult) {
        while ($registo = mysqli_fetch_array( $queryResult )){ 
            $img = $registo['img'];
           
        }         
        
        
    } 
          
    
        if (!file_exists('C:/temp/upload/')) {
            mkdir('C:/temp/upload/', 0777, true);
        }   
        
        $filename = "C:/Temp/upload/" . $img;
            
        $im = imagecreatefrompng($filename); 
            
             
        // The PHP-file will be rendered as image 
        header('Content-type: image/png'); 
            
        ob_clean();
            
        // Finally output the captcha as 
        // PNG image the browser 
        imagepng($im); 
            
        // Free memory 
        imagedestroy($im); 
        
?>

