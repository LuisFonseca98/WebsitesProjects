<?php 

require_once( "../../Lib/lib.php" );
require_once( "../../Lib/db.php" );


if (!isset($_SESSION)) {
    session_start();
}

$_SESSION['locationAfterAdd'] = "conteudosWebsiteCursos.php";

dbConnect(ConfigFile);
$dataBaseName = $GLOBALS['configDataBase']->db;
mysqli_select_db( $GLOBALS['ligacao'], $dataBaseName );  

$userRole = 4;

if(isset($_SESSION['id'])){
    $query = "SELECT `role` FROM `$dataBaseName` . `auth-permissions` where `id`= " . $_SESSION['id'];
    $queryResult = mysqli_query( $GLOBALS['ligacao'], $query );
    if ($queryResult) {
        while ($registo = mysqli_fetch_array( $queryResult )){
                $userRole = $registo['role'];
            }         
    }
}    
    
if($userRole <= 2){
    echo '<div class="sidenav">';
        echo'<a onclick="novaSeccao()">-Novo Curso</a>';
        echo'<a onclick="deleteForm()">-Apagar Curso</a>';
        echo'<a href ="../../Dashboard/dashboard.php">-Alterar Role Utilizador</a>';
        echo'<a onclick="hiddenCourse()">-Alterar Visibilidade do Curso</a>';
        echo'<a href ="../../Dashboard/changeDBaccess.php">-Alterar Acesso à Base de Dados</a>';
    echo'</div>';
}
dbDisconnect();


function runMyFunction(int $requiredRole, String $nxtPage, String $idC) {
    include( "./ensureAuth.php");
   
    $_SESSION['idC'] = $idC;
    
    dbConnect(ConfigFile);
    $dataBaseName = $GLOBALS['configDataBase']->db;
    mysqli_select_db( $GLOBALS['ligacao'], $dataBaseName );  
    $query = "SELECT `role` FROM `$dataBaseName` . `auth-permissions` where `id`= " . $_SESSION['id'];
   
    $userRole = 4;
    $queryResult = mysqli_query( $GLOBALS['ligacao'], $query );
    if ($queryResult) {
        while ($registo = mysqli_fetch_array( $queryResult )){
            $userRole = $registo['role'];
        }         
    }    
    dbDisconnect();
    if($userRole <= $requiredRole){
        echo "<script type='text/javascript'>window.location.href = '../conteudosDiversos/course_page.php';</script>";        
    }
    
    else{
        echo "<script type='text/javascript'>alert('Não tem autorização para aceder');</script>";
    }
  }
      
  if (isset($_GET['role']) && isset($_GET['nxt']) && isset($_GET['idC'])) {
    runMyFunction($_GET['role'], $_GET['nxt'], $_GET['idC']);
  }
  
  $text = "";
  $link = "";
        
  if (isset($_SESSION['username']) ) {
    $text = "Logout";
    $link = "../../Login/logout.php";
    }
    else{
        $text = "Login";
        $link = "../../Login/processFormLogin.php";
    }

?>
<head>
  <title>Cursos</title>
</head>
<h1 id="title"> Cursos Disponíveis</h1>


<?php
    $uploadDir = "C:/Temp/upload/";
    dbConnect(ConfigFile);
    $dataBaseName = $GLOBALS['configDataBase']->db;
    mysqli_select_db( $GLOBALS['ligacao'], $dataBaseName );  
    $query = "SELECT * FROM `$dataBaseName` . `curso`";
    $img = "";
    $queryResult = mysqli_query( $GLOBALS['ligacao'], $query );  
    
    if ($queryResult) {
        while ($registo = mysqli_fetch_array( $queryResult )){
            $idCurso = $registo['id_curso'];
            $nome_curso = $registo['nome_curso'];
            $duracao = $registo['duracao'];
            $img = $registo['img'];
            $required_role = $registo['required_role'];
            $video = $registo['video'];
            $nxtPage = "course_page";
            $tag = $registo['tag'];
            $visible = $registo['visible'];
            $aceder = 0;
            $isAdmin = 0;
            if($visible == 1){    
                $aceder = 1;
            }
            if($userRole <= 2){
                $aceder = 1;
                $isAdmin = 1;   
            }    
            if($aceder == 1){
                echo "<div id='". $tag ."' class='card'>";
                echo "<div class='card_left'>";
                echo "<a href ='./conteudosWebsiteCursos.php?role=" .$required_role."&nxt=".$nxtPage."&idC=".$idCurso."'>\n";
                echo "<img width='225' height='320' src = './getThumbnail.php?idC=" . $idCurso. "'>";
                echo "</a>\n";
                echo "</div>";
                echo "<div class='card_right'>";
                echo "<h1>".$nome_curso."</h1>";
                echo "<h1>Duração: ". $duracao ." </h1>";
                echo "<h1>Tag: ". $tag ."</h1>";
                if($isAdmin){
                    $tipo = "Privado";
                    if($visible == 1){$tipo = "Público";}
                    echo "<h1>Tipo: " . $tipo . "</h1>";    
                }
                echo "</div>";
                echo "</div>";   
            }    
        }         
    }     
    dbDisconnect();  
?>

<link rel="stylesheet" href="cssMain/sideMenu.css">
<link rel="stylesheet" href="cssMain/style.css">
<link rel="stylesheet" href="cssMain/mainPage.css"> 

<script>theVideo = document.getElementById( "my_video" );</script>
<ul>
<?php echo "<li><a href='".$link."'><span class='notranslate'>".$text."</span></a></li>" ?>
    <li><a class="active">Cursos</a></li>
    <li><a href="../../About/about.php"><span class='notranslate'>About</span></a></li>
    <li><a href="../../PaginaPrincipal/PaginaPrincipal.php"><span class='notranslate'>Home</span></a></li>
    <li class="li" <a id="translate"> <div id="google_translate_element"></div></a></li>
    <input type="text" id="pesquisar_curso" placeholder="Pesquisar Curso" onkeyup="myFunction()">
</ul>


<div class="form-popup" id="myForm">
  <form action="./newCourse.php" class="form-container"
        enctype="multipart/form-data"
        method="POST"
        name="FormUpload">
    <h1>Criar Secção</h1>

    <label><b>Nome Curso:</b></label>
    <input type="text" placeholder="Introduzir Nome do Curso" name="nome_curso" required>

    <label><b>Duracao</b></label>
    <input type="text" placeholder="Introduzir Duração do Curso" name="duracao" required>

    <label><b>Imagem</b></label>
    <input type="file" size="64" placeholder="Introduzir Imagem do Curso" name="imageFile" required>
    
    <label><b>Role</b></label>
    <input type="text" placeholder="Introduzir Role do Curso" name="role" required>

    <label><b>Tag</b></label>
    <input type="text" placeholder="Introduzir Tag do Curso" name="tag" required>

    <label><b>Video</b></label>
    <input type="file" size="64" placeholder="Introduzir Video do Curso" name="videoFile" required>
    
    <input type="radio" name="privacy" value="1">
    <label for="public"> Público</label><br>
    
    <input type="radio" name="privacy" value="0">
    <label for="private"> Privado</label><br>
    
    <button type="submit" class="btn">Criar</button>
    <button type="button" class="btn cancel" onclick="closeForm()">Fechar</button>
  </form>
</div>


<div class="form-popup" id="myFormVisible">
    <form action="./changeVisibleCourse.php" class="form-container"
        enctype="multipart/form-data"
        method="POST"
        name="FormUpload">
        <label><b>Tag do curso</b></label>
            <input type="text" placeholder="Mudar Visibilidade do Curso" name="tag" required>
                <input type="radio" name="privacy" value="1">
                    <label for="public"> Público</label><br>
                <input type="radio" name="privacy" value="0">
                    <label for="private"> Privado</label><br>
        <button type="submit" class="btn">Alterar</button>
        <button type="button" class="btn cancel" onclick="closeFormVisible()">Fechar</button>
        </form>
</div>

<script>    
function novaSeccao() {
  document.getElementById("myForm").style.display = "block";
}

function closeForm() {
  document.getElementById("myForm").style.display = "none";
}

function deleteForm() {
    var input = prompt("Tag do curso a apagar", "");
    if (input != null) {
        window.location="./delete.php?deleteTag="+input;
    } 
}

function closeFormVisible(){
    document.getElementById("myFormVisible").style.display = "none";
}

function hiddenCourse(){
    document.getElementById("myFormVisible").style.display = "block";
}

function changeEvent(){
    var courses = document.getElementsByClassName("Card");
    for(var i=0; i<courses.length; i++){
        if(courses[i].id !== document.getElementById("pesquisar_curso").value)
            courses[i].style.display='none';
    }    
}

function myFunction() {
    var input, filter, a, i, txtValue;
    input = document.getElementById("pesquisar_curso");
    filter = input.value.toUpperCase();
    var courses = document.getElementsByClassName("Card");
    for(var i=0; i<courses.length; i++){
        a = courses[i];
        txtValue = a.id;
        if (txtValue.toUpperCase().indexOf(filter) > -1) {
            courses[i].style.display = "";
        } else {
            courses[i].style.display = "none";
        }
    }
}

function googleTranslateElementInit() { 
    new google.translate.TranslateElement({pageLanguage: 'pt', includedLanguages: 'en,es,fr,pt', 
        layout: google.translate.TranslateElement.InlineLayout.SIMPLE},'google_translate_element');
}
</script>
<script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
    












