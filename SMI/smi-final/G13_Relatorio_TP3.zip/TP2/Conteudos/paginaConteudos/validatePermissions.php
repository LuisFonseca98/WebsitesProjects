<?php
include( "../../Login/ensureAuth.php");

$user_role = 3; //dps obter o do login

$required_role = $_SESSION['required_role'];          
        

if($user_role <= $required_role){
    echo 'DEU';
}

ELSE{
    echo 'NAO DEU';
}
?>
