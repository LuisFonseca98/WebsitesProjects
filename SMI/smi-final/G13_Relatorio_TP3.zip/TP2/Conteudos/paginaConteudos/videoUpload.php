<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

// Maximum time allowed for the upload
set_time_limit( 300 );

if ($_FILES['videoFile']['error'] != 0) {
    // Handle the error
    $errorCode = $_FILES['videoFile']['error'];

    echo showUploadFileError($errorCode);

    exit($errorCode);
}

$srcName = $_FILES['videoFile']['name'];

// Read configurations from data base
$configurations = getConfiguration();
$dstDir = $configurations['destination'];


if (!file_exists('C:/temp/upload/')) {
    mkdir('C:/temp/upload/', 0777, true);
}   

// Destination for the uploaded file
$src = $_FILES['videoFile']['tmp_name'];
$dst = $dstDir . DIRECTORY_SEPARATOR . $srcName;

$copyResult = copy($src, $dst);

if ( $copyResult === false ) {
    echo "Could not write \"$src\" to \"$dst\".\n<br>";
    exit();
}

unlink($src);

echo "File uploaded with sucess.\n<br>";

$fileInfo = finfo_open(FILEINFO_MIME);

$fileInfoData = finfo_file($fileInfo, $dst);
print_r($fileInfoData);

$fileTypeComponents = explode(";", $fileInfoData);

$mimeTypeFileUploaded = explode("/", $fileTypeComponents[0]);
$mimeFileName = $mimeTypeFileUploaded[0];
$typeFileName = $mimeTypeFileUploaded[1];

$thumbsDir = $dstDir . DIRECTORY_SEPARATOR . "thumbs";
$pathParts = pathinfo($dst);

$lat = "";
$lon = "";


$width = $configurations['thumbWidth'];
$height = $configurations['thumbHeight'];

echo "File is of type $mimeFileName<br>\n";

$imageFileNameAux = null;
$imageMimeFileName = null;
$imageTypeFileName = null;

$thumbFileNameAux = null;
$thumbMimeFileName = null;
$thumbTypeFileName = null;

switch ($mimeFileName) {
    case "image":
        $exif = @exif_read_data($dst, 'IFD0', true);
        
        if ($exif === false) {
            echo "No exif header data found.<br>\n";
        }
        else {
            //Just for Debug - Begin
         
                        echo "<pre>";
                        foreach ($exif as $key => $section) {
                          foreach ($section as $name => $val) {
                            echo "$key.$name: $val<br>\n";
                          }
                        }
                        echo "</pre>";
           
            //Just for Debug - End

            $gps = $exif['GPS'];
            if ( $gps!=NULL ) {
                $latitudeAux = $gps['GPSLatitude'];
                $latitudeRef = $gps['GPSLatitudeRef'];
                $longitudeAux = $gps['GPSLongitude'];
                $longitudeRef = $gps['GPSLongitudeRef'];

                if ( ($latitudeAux!=NULL ) && ( $longitudeAux!=NULL ) ) {
                    $lat = getCoordAsString($latitudeAux, $latitudeRef);
                    $lon = getCoordAsString($longitudeAux, $longitudeRef);
                    echo "File latitude: $lat<br>\n";
                    echo "File longitued: $lon<br>\n";
                }
                else {
                    echo "File does have GPS coordenates<br>\n";
                }
            }
            else {
                echo "File does have GPS coordenates<br>\n";
            }
        }

        $imageFileNameAux = $dst;
        $imageMimeFileName = "image";
        $imageTypeFileName = $typeFileName;

        $thumbFileNameAux = $thumbsDir . DIRECTORY_SEPARATOR . $pathParts['filename'] . "." . $typeFileName;
        $thumbMimeFileName = "image";
        $thumbTypeFileName = $typeFileName;

    break;

    case "video":
        $size = "$width" . "x" . "$height";

        $imageFileNameAux = $thumbsDir . DIRECTORY_SEPARATOR . $pathParts['filename'] . "-Large.jpg";
        $imageMimeFileName = "image";
        $imageTypeFileName = "jpeg";
        echo "Generating video 1st image...<br>\n";

        // -itsoffset -1 -> "avança" o filme 1 segundo
        // -i $dst -> input file
        // -vcodec mjpeg -> codec do tipo mjpeg
        // -vframes 1 -> obter uma frame
        // -s 640x480 -> dimensão do output
        $cmdFirstImage = " $ffmpegBinary -itsoffset -1 -i $dst -vcodec mjpeg -vframes 1 -an -f rawvideo -s 640x480 $imageFileNameAux";
        
        echo "$cmdFirstImage<br>\n";
        system($cmdFirstImage, $status);
        echo "Status from the generation of video 1st image: $status.<br>\n";

        $thumbFileNameAux = $thumbsDir . DIRECTORY_SEPARATOR . $pathParts['filename'] . ".jpg";
        $thumbMimeFileName = "image";
        $thumbTypeFileName = "jpeg";
        echo "Generating video thumb...<br>\n";

        $cmdVideoThumb = "$ffmpegBinary -itsoffset -5  -i $dst -vcodec mjpeg -vframes 1 -an -f rawvideo -s $size $thumbFileNameAux";
        echo "$cmdVideoThumb<br>\n";
        system($cmdVideoThumb, $status);
        echo "Status from the generation of video thumb: $status.<br>\n";
    break;

    case "audio":
        require_once( "Zend/Media/Id3v2.php" );

        $id3 = new Zend_Media_Id3v2($dst);

        $mimeTypeAudioAPIC = explode("/", $id3->apic->mimeType);
        //$mimeAudioAPIC = $mimeTypeAudioAPIC[0];
        $typeAudioAPIC = $mimeTypeAudioAPIC[1];

        $imageFileNameAux = $thumbsDir . DIRECTORY_SEPARATOR . $pathParts['filename'] . "-Large." . $typeAudioAPIC;
        $imageMimeFileName = "image";
        $imageTypeFileName = $typeAudioAPIC;
        $fdMusicImage = fopen($imageFileNameAux, "wb");
        fwrite($fdMusicImage, $id3->apic->getImageData());
        fclose($fdMusicImage);

        $thumbFileNameAux = $thumbsDir . DIRECTORY_SEPARATOR . $pathParts['filename'] . "." . $typeAudioAPIC;
        $thumbMimeFileName = "image";
        $thumbTypeFileName = $typeAudioAPIC;
        $resizeObj = new ImageResize($imageFileNameAux);
        $resizeObj->resizeImage($width, $height, 'crop');
        $resizeObj->saveImage($thumbFileNameAux, $typeAudioAPIC, 100);
        $resizeObj->close();
    break;

    default:
        $imageFileNameAux = $dstDir . DIRECTORY_SEPARATOR . "default" . DIRECTORY_SEPARATOR . "Unknown-Large.jpg";
        $imageMimeFileName = "image";
        $imageTypeFileName = "jpeg";

        $thumbFileNameAux = $dstDir . DIRECTORY_SEPARATOR . "default" . DIRECTORY_SEPARATOR . "Unknown.jpg";
        $thumbMimeFileName = "image";
        $thumbTypeFileName = "jpeg";
    break;
}


?>