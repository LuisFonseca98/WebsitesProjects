<?php

if (!isset($_SESSION)) {
    session_start();
}

require_once( "../../Lib/lib.php" );
require_once( "../../Lib/db.php" );

dbConnect(ConfigFile);
$dataBaseName = $GLOBALS['configDataBase']->db;
mysqli_select_db( $GLOBALS['ligacao'], $dataBaseName ); 

if (isset($_POST['tag'])) {
    
    $query = "UPDATE `curso` SET `visible`= '".$_POST['privacy'] ."' where `tag`='".$_POST['tag']."'";

    
    mysqli_query($GLOBALS['ligacao'], $query);
}
dbDisconnect();

$serverName = "localhost";
$serverPort = 80;
$name = webAppName();
$baseUrl = "http://" . $serverName . ":" . $serverPort;
$baseNextUrl = $baseUrl . $name;
$nextUrl = $_SESSION['locationAfterAdd'];
header("Location: " . $baseNextUrl . $nextUrl);
?>
