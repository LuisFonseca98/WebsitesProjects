<?php

require_once( "../../Lib/lib.php" );
require_once( "../../Lib/db.php" );

if (!isset($_SESSION)) {
    session_start();
}

dbConnect(ConfigFile);
$dataBaseName = $GLOBALS['configDataBase']->db;
mysqli_select_db( $GLOBALS['ligacao'], $dataBaseName );  

$query = "DELETE FROM `curso` WHERE tag='".$_GET["deleteTag"]."'";
$queryResult = mysqli_query( $GLOBALS['ligacao'], $query );   


$serverName = "localhost";
$serverPort = 80;
$name = webAppName();
$baseUrl = "http://" . $serverName . ":" . $serverPort;
$baseNextUrl = $baseUrl . $name;
$nextUrl = "conteudosWebsiteCursos.php";

header("Location: " . $baseNextUrl . $nextUrl);

?>


