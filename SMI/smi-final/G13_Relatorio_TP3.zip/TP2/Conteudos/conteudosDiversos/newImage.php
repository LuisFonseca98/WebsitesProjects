<?php

if (!isset($_SESSION)) {
    session_start();
}

require_once( "../../Lib/lib.php" );
require_once( "../../Lib/db.php" );

dbConnect(ConfigFile);
$dataBaseName = $GLOBALS['configDataBase']->db;
mysqli_select_db( $GLOBALS['ligacao'], $dataBaseName );  

if(isset($_POST['titulo'])){
    
    $query = "SELECT `id_conteudo` FROM `$dataBaseName` . `conteudo` where titulo=". "'".$_POST['titulo']."'" ;
    $idCImg = "";
    $queryResult = mysqli_query($GLOBALS['ligacao'], $query);

    if($queryResult){
        while($registo = mysqli_fetch_array($queryResult)){
            $idCImg = $registo['id_conteudo'];
        }
    }
    $queryImage = "INSERT INTO `images`(`id_conteudo`,`img`)"
                . " VALUES('".$idCImg."', '".$_FILES['imageFile']['name']."')";
        mysqli_query($GLOBALS['ligacao'], $queryImage);

}
dbDisconnect();
include_once './imageUpload.php';

//
$serverName = "localhost";
$serverPort = 80;
$name = webAppName();
$baseUrl = "http://" . $serverName . ":" . $serverPort;
$baseNextUrl = $baseUrl . $name;
$nextUrl = $_SESSION['locationAfterAdd'];

echo $baseNextUrl . $nextUrl;

header("Location: " . $baseNextUrl . $nextUrl);
?>

