<?php

require_once( "../../Lib/lib.php" );
require_once( "../../Lib/db.php" );

if (!isset($_SESSION)) {
    session_start();
}

dbConnect(ConfigFile);
$dataBaseName = $GLOBALS['configDataBase']->db;
mysqli_select_db( $GLOBALS['ligacao'], $dataBaseName );  

$idConteudo = "";

$query = "SELECT id_conteudo FROM $dataBaseName . conteudo WHERE titulo='".$_GET["deleteConteudo"]."'" ;

$queryResult = mysqli_query( $GLOBALS['ligacao'], $query ); 

if($queryResult){
    while ($registo = mysqli_fetch_array($queryResult)){
        $idConteudo = $registo['id_conteudo'];
    }
}

$query = "DELETE FROM images WHERE id_conteudo=". $idConteudo;
mysqli_query( $GLOBALS['ligacao'], $query ); 

$query = "DELETE FROM video WHERE id_conteudo=". $idConteudo;
mysqli_query( $GLOBALS['ligacao'], $query ); 

$query = "DELETE FROM conteudo WHERE titulo='".$_GET["deleteConteudo"]."'";
mysqli_query( $GLOBALS['ligacao'], $query ); 



$serverName = "localhost";
$serverPort = 80;
$name = webAppName();
$baseUrl = "http://" . $serverName . ":" . $serverPort;
$baseNextUrl = $baseUrl . $name;
$nextUrl = "course_page.php";

header("Location: " . $baseNextUrl . $nextUrl);

?>