<?php

if (!isset($_SESSION)) {
    session_start();
}


require_once( "../../Lib/lib.php" );
require_once( "../../Lib/db.php" );

dbConnect(ConfigFile);
$dataBaseName = $GLOBALS['configDataBase']->db;
mysqli_select_db( $GLOBALS['ligacao'], $dataBaseName );  


if(isset($_POST['titulo'])){
    $query = "SELECT `id_conteudo` FROM `$dataBaseName` . `conteudo` where titulo=". "'".$_POST['titulo']."'" ;


    $idCVideo = "";

    $queryResult = mysqli_query($GLOBALS['ligacao'], $query);

    if($queryResult){
        while($registo = mysqli_fetch_array($queryResult)){
            $idCVideo = $registo['id_conteudo'];

        }
    }

    $query = "INSERT INTO `video`(`id_conteudo`,`video`)"
            . " VALUES('".$idCVideo."', '".$_FILES['videoFile']['name']."')";
    mysqli_query($GLOBALS['ligacao'], $query);

}

dbDisconnect();

include_once './videoUpload.php';


//
$serverName = "localhost";
$serverPort = 80;
$name = webAppName();
$baseUrl = "http://" . $serverName . ":" . $serverPort;
$baseNextUrl = $baseUrl . $name;
$nextUrl = $_SESSION['locationAfterAdd'];

echo $baseNextUrl . $nextUrl;

header("Location: " . $baseNextUrl . $nextUrl);
?>

