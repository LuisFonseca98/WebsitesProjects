<?php

    require_once( "../../Lib/lib.php" );
    require_once( "../../Lib/db.php" );
    dbConnect(ConfigFile);
    $dataBaseName = $GLOBALS['configDataBase']->db;
    mysqli_select_db( $GLOBALS['ligacao'], $dataBaseName );


    $img = $_GET['img'];

    if (!file_exists('C:/temp/upload/')) {
        mkdir('C:/temp/upload/', 0777, true);
    }
    
    $filename = "C:/Temp/upload/". $img;

    // Generate a 50x24 standard captcha image 
    $im = imagecreatefrompng($filename); 


    // The PHP-file will be rendered as image 
    header('Content-type: image/png'); 

    ob_clean();

    // Finally output the captcha as 
    // PNG image the browser 
    imagepng($im); 

    // Free memory 
    imagedestroy($im);




    dbDisconnect();
?>