<?php
    require_once( "../../Lib/lib.php" );
    require_once( "../../Lib/db.php" );
    dbConnect(ConfigFile);
    $dataBaseName = $GLOBALS['configDataBase']->db;
    mysqli_select_db( $GLOBALS['ligacao'], $dataBaseName );  
   
        $video = $_GET['video'];

        if (!file_exists('C:/temp/upload/')) {
            mkdir('C:/temp/upload/', 0777, true);
        }      
        
        $filename = "C:/Temp/upload/" . $video;
        $mimeFileName = 'video';
        $typeFileName = 'mp4';    
        
        $fileHandler = fopen($filename, 'rb');

        /*echo ("Content-Type: $mimeFileName/$typeFileName");
        echo ("Content-Length: " . filesize($filename));

        echo ( "Content-Transfer-Encoding: Binary" );
        echo ( "Content-disposition: attachment; filename=\"" . $filename . "\""); */
        
        header("Content-Type: $mimeFileName/$typeFileName");
        header("Content-Length: " . filesize($filename));

        header( "Content-Transfer-Encoding: Binary" );
        header( "Content-disposition: attachment; filename=\"" . basename($filename) . "\""); 

        fpassthru($fileHandler);
        fclose($fileHandler);
    
?>

