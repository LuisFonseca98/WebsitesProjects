<?php

if (!isset($_SESSION)) {
    session_start();
}

require_once( "../../Lib/lib.php");
require_once( "../../Lib/lib-mail-v2.php" );
require_once( "../../Lib/HtmlMimeMail-class.php" );
require_once( "../../Lib/db.php" );

dbConnect(ConfigFile);
$dataBaseName = $GLOBALS['configDataBase']->db;
mysqli_select_db( $GLOBALS['ligacao'], $dataBaseName );  

if (isset($_POST['titulo']) 
        && isset($_POST['descricao'])) {
    
    $query = "INSERT INTO `conteudo`(`titulo`,`descricao`)"
            . " VALUES('".$_POST['titulo']."', '".$_POST['descricao']."')";
    mysqli_query($GLOBALS['ligacao'], $query);

    $query = "SELECT MAX(`id_conteudo`) AS 'maxID' FROM `$dataBaseName` . `conteudo`";
    $maxID = "";
    $queryResult = mysqli_query( $GLOBALS['ligacao'], $query );
    if ($queryResult) {
        while ($registo = mysqli_fetch_array( $queryResult )){ 
            $maxID = $registo['maxID'];
        }         
    } 
    
    $query = "INSERT INTO `curso_conteudo`(`id_curso`,`id_conteudo`)"
            . " VALUES('".$_SESSION['idC']."', '".$maxID."')";
    mysqli_query($GLOBALS['ligacao'], $query);    
    
    $query = "INSERT INTO `images`(`id_conteudo`,`img`)"
            . " VALUES('".$maxID."', '".$_FILES['imageFile']['name']."')";
    mysqli_query($GLOBALS['ligacao'], $query);

    //echo $query . "\n";
    
    $query = "INSERT INTO `video`(`id_conteudo`,`video`)"
            . " VALUES('".$maxID."', '".$_FILES['videoFile']['name']."')";
    mysqli_query($GLOBALS['ligacao'], $query);

    //echo $query . "\n"; 
    $query = "SELECT * FROM `$dataBaseName` . `inscricao`";    
    $queryResult = mysqli_query( $GLOBALS['ligacao'], $query );
    if ($queryResult) {
        while ($registo = mysqli_fetch_array( $queryResult )){
            $id_user = $registo['id'];
            $idCurso = $registo['idCurso'];        
            
            $query2 = "SELECT * FROM `$dataBaseName` . `auth-basic` where `id`= " . $id_user;
            $queryResult2 = mysqli_query( $GLOBALS['ligacao'], $query2 );
            if ($queryResult2) {
                while ($registo2 = mysqli_fetch_array( $queryResult2 )){
                    $nome = $registo2['name'];
                    $email = $registo2['email'];
                    
                    $curso_nome = "";

                    $query3 = "SELECT `nome_curso` FROM `$dataBaseName` . `curso` where `id_curso`= " . $idCurso;
                    $queryResult3 = mysqli_query( $GLOBALS['ligacao'], $query3 );
                    if ($queryResult) {
                        while ($registo3 = mysqli_fetch_array( $queryResult3 )){
                                $curso_nome = $registo3['nome_curso'];
                            }         
                    } 
                    
                    $Account = 1;
                    $ToName = "";
                    $ToEmail = $email;
                    $Subject = "E-Learning - Novos Conteudos";
                    $Message = "Caro " . $nome . " o curso de " . $curso_nome . " recebeu novos conteúdos. Mantenha-se a par!";  
                    $smtpServer = "smtp.gmail.com";
                    $mail = new HtmlMimeMail();
$MessageHTML = <<<EOD
<html>
    <body style="background: url('background.gif') repeat;">
        <font face="Verdana, Arial" color="#FF0000">
            $Message
        </font>
    </body>
</html>
EOD;
            $mail->add_html( $MessageHTML, $Message);
            $mail->build_message();
            $result = $mail->send(
                  $smtpServer,
                  1,
                  465,
                  "iselg13smi@gmail.com",
                  "isel1920",
                  $ToName, 
                  $ToEmail,
                  "G13-SMI", 
                  "iselg13smi@gmail.com",
                  $Subject,
                  "X-Mailer: Html Mime Mail Class");
                        }         
                    }             
                }         
            }  
    
}
dbDisconnect();
//

include_once './imageUpload.php';
include_once './videoUpload.php';

//
$serverName = "localhost";
$serverPort = 80;
$name = webAppName();
$baseUrl = "http://" . $serverName . ":" . $serverPort;
$baseNextUrl = $baseUrl . $name;
$nextUrl = $_SESSION['locationAfterAdd'];

echo $baseNextUrl . $nextUrl;

header("Location: " . $baseNextUrl . $nextUrl);
?>

