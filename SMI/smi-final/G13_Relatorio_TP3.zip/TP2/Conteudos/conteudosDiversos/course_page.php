
<?php

require_once( "../../Lib/lib.php" );
require_once( "../../Lib/db.php" );

if (!isset($_SESSION)) {
    session_start();
}

$_SESSION['locationAfterAdd'] = "course_page.php";
dbConnect(ConfigFile);
$dataBaseName = $GLOBALS['configDataBase']->db;
mysqli_select_db( $GLOBALS['ligacao'], $dataBaseName );  
$query = "SELECT `role` FROM `$dataBaseName` . `auth-permissions` where `id`= " . $_SESSION['id'];
   
$userRole = 4;
$queryResult = mysqli_query( $GLOBALS['ligacao'], $query );
if ($queryResult) {
    while ($registo = mysqli_fetch_array( $queryResult )){
            $userRole = $registo['role'];
        }         
}    
    
if($userRole <= 2){
    echo '<div class="sidenav">';
        echo'<a onclick="novaSeccao()">-Nova Secção</a>';
        echo'<a onclick="novaImagemNav()">-Nova Imagem</a>';
        echo'<a onclick="novoVideoNav()">-Novo Video</a>';
        echo'<a onclick="deleteForm()">-Apagar Conteúdo</a>';
        echo'<a href ="../../Dashboard/dashboard.php">-Alterar Role Utilizador</a>';
    echo'</div>';
}
   
    $query = "SELECT `nome_curso` FROM `$dataBaseName` . `curso` where id_curso=". $_SESSION['idC']; 
    $queryResult = mysqli_query( $GLOBALS['ligacao'], $query );
    if ($queryResult) {
        while ($registo = mysqli_fetch_array( $queryResult )){
            $nomeCurso = $registo['nome_curso'];
            echo "<title>Curso de ". $nomeCurso ."</title>";
            echo "<h1 id='title'>".$nomeCurso."</h1>";
            
        }         
    } 
    
    echo '<button id="myBtn">Inscrever em Curso</button>';
    
    $query = "SELECT * FROM `$dataBaseName` . `curso_conteudo` where id_curso=" . $_SESSION['idC'];    
    $queryResult = mysqli_query( $GLOBALS['ligacao'], $query );
    if ($queryResult) {
        while ($registo = mysqli_fetch_array( $queryResult )){
            $id_cont = $registo['id_conteudo'];
            $query2 = "SELECT * FROM `$dataBaseName` . `conteudo` where id_conteudo=". $id_cont; 
            $queryResult2 = mysqli_query( $GLOBALS['ligacao'], $query2 );
            if ($queryResult2) {
                while ($registo2 = mysqli_fetch_array( $queryResult2 )){
                    $titulo = $registo2['titulo'];
                    $descricao = $registo2['descricao'];
                    $idConteudo = $registo2['id_conteudo'];
                    
                    echo "<h2 class='titulo'>➔ ".$titulo."</h2>";
                    
                    $queryImage = "SELECT * FROM `$dataBaseName` . `images` where id_conteudo=" .$idConteudo;    
                    $queryResultImage= mysqli_query( $GLOBALS['ligacao'], $queryImage );
                    if ($queryResultImage) {
                        while ($registoImage = mysqli_fetch_array( $queryResultImage )){
                            $image = $registoImage['img'];
                            $idCont = $registoImage['id_conteudo'];           
                            echo "<img class='imagem' src = './getThumbnailConteudo.php?img=" . $image. "' />\n";
                            echo "<br/>";
                        }         
                    }
                    echo "<p class='descricao'>Descrição:</p>";
                    echo "<p class='descricao2'>".$descricao."</p>";            
                    
                    $queryVideo = "SELECT * FROM `$dataBaseName` . `video` where id_conteudo=" .$idConteudo;    
                    $queryResultVideo= mysqli_query( $GLOBALS['ligacao'], $queryVideo );
                    
                    if ($queryResultVideo) {
                        while ($registoVideo = mysqli_fetch_array( $queryResultVideo )){
                            $video = $registoVideo['video'];
                            echo "<div class='video' id='video_area'>\n";
                            echo "<video id='my_video' width='640' height='500'  controls preload='metadata' >\n";
                            echo "<source src='./getVideo.php?video=" . $video. "' type='video/mp4' />\n";
                            echo "<track label='English' kind='subtitles' srclang='en' src='subtitles/vtt/videoDemo-en.vtt'>\n";
                            echo "</video>\n";        
                            echo "</div>\n";
                        }         
                    }
                    echo "<br>";
                    echo "<br>";            
                    echo "<hr class='separator'>";
                    echo "<br>";
                    echo "<br>";
                }         
            }  
        }         
    }    
    
    $text = "";
    $link = "";
        
    if (isset($_SESSION['username']) ) {
    $text = "Logout";
    $link = "../../Login/logout.php";
    }
    else{
        $text = "Login";
        $link = "../../Login/processFormLogin.php";
    }
     
    
dbDisconnect();

?>

<link rel="stylesheet" href="cssMain/sideMenu.css">
<link rel="stylesheet" href="cssMain/mainPage.css">

<ul>
    <?php echo "<li><a href='".$link."'><span class='notranslate'>".$text."</span></a></li>" ?>
    <li><a href="../../About/about.php">About</a></li>
    <li><a href="../paginaConteudos/conteudosWebsiteCursos.php"><span class='notranslate'>Cursos</span></a></li>
    <li><a href="../../PaginaPrincipal/PaginaPrincipal.php"><span class="notranslate">Home</span></a></li>
    <li class="li" <a id="translate"> <div id="google_translate_element"></div></a></li>
</ul>

<div class="form-popup" id="myForm">
  <form action="./newContent.php" class="form-container"
        enctype="multipart/form-data"
        method="POST"
        name="FormUpload">
    <h1>Criar Secção</h1>

    <label><b>Titulo:</b></label>
    <input type="text" placeholder="Introduzir Título do Conteúdo" name="titulo" >

    <label><b>Descricao</b></label>
    <input type="text" placeholder="Introduzir Descricao do Conteúdo" name="descricao" >

    <label><b>Imagem</b></label>
    <input type="file" size="64" placeholder="Introduzir Imagem do Conteúdo" name="imageFile" >
   
    <label><b>Video</b></label>
    <input type="file" size="64" placeholder="Introduzir Video do Conteúdo" name="videoFile" >
    
    <button type="submit" class="btn">Criar</button>
    <button type="button" class="btn cancel" onclick="closeForm()">Fechar</button>
  </form>
</div>

<div class="form-popup" id="myFormImage">
    <form action="./newImage.php" class="form-container"
        enctype="multipart/form-data"
        method="POST"
        name="FormUploadImage">
    <h1>Inserir Imagem</h1>

    <label><b>Conteudo:</b></label>
    <input id="conteudo" type="text" placeholder="Introduzir Conteúdo" name="titulo" required>

    <label><b>Imagem</b></label>
    <input id="image" type="file" size="64" placeholder="Introduzir Imagem do Conteúdo" name="imageFile" required>



    <button type="submit" class="btn" onclick="novaImagem()">Criar</button>
    <button type="button" class="btn cancel" onclick="closeFormImage()">Fechar</button>
  </form>
</div>

<div class="form-popup" id="myFormVideo">
    <form action="./newVideo.php" class="form-container"
        enctype="multipart/form-data"
        method="POST"
        name="FormUploadVideo">
    <h1>Inserir Video</h1>

    <label><b>Conteudo:</b></label>
    <input id="conteudo" type="text" placeholder="Introduzir Conteúdo" name="titulo" required>

    <label><b>Video</b></label>
    <input id="video" type="file" size="64" placeholder="Introduzir Video do Conteúdo" name="videoFile" required>



    <button type="submit" class="btn" onclick="novoVideo()">Criar</button>
    <button type="button" class="btn cancel" onclick="closeFormVideo()">Fechar</button>
  </form>
</div>

<script>
function novaSeccao() {
  document.getElementById("myForm").style.display = "block";
}

function closeForm() {
  document.getElementById("myForm").style.display = "none";
}

var btn = document.getElementById('myBtn');
btn.addEventListener('click', function() {
  document.location.href = './subscribe.php?idCurso=' + "<?php echo $_SESSION['idC'];?>";
});

function novaImagemNav(){
    document.getElementById("myFormImage").style.display = "block";
}

function novaImagem() {
    var input = document.getElementById("conteudo").value;
    if(input!=null){
        window.location = "./newImage.php?titulo="+input;
    }
}

function novoVideoNav(){
    document.getElementById("myFormVideo").style.display = "block";
}

function novoVideo() {
    var input = document.getElementById("conteudo").value;
    console.log(input);
    window.location = "./newVideo.php?titulo="+input;
}

function closeFormVideo() {
  document.getElementById("myFormVideo").style.display = "none";
}

function closeFormImage() {
  document.getElementById("myFormImage").style.display = "none";
}

function deleteForm() {
    var input = prompt("Título do conteúdo a apagar", "");
    if (input != null) {
        window.location="./deleteConteudo.php?deleteConteudo="+input;
    } 
}
function googleTranslateElementInit() { 
    new google.translate.TranslateElement({pageLanguage: 'pt', includedLanguages: 'en,es,fr,pt', 
        layout: google.translate.TranslateElement.InlineLayout.SIMPLE},'google_translate_element');
}
</script>
<script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>


