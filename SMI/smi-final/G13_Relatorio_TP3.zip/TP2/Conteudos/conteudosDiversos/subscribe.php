<?php

require_once( "../../Lib/lib.php" );
require_once( "../../Lib/db.php" );

if (!isset($_SESSION)) {
    session_start();
}

dbConnect(ConfigFile);
$dataBaseName = $GLOBALS['configDataBase']->db;
mysqli_select_db( $GLOBALS['ligacao'], $dataBaseName );  
$query = "SELECT `role` FROM `$dataBaseName` . `auth-permissions` where `id`= " . $_SESSION['id'];
   
$userRole = 4;
$queryResult = mysqli_query( $GLOBALS['ligacao'], $query );
if ($queryResult) {
    while ($registo = mysqli_fetch_array( $queryResult )){
            $userRole = $registo['role'];
        }         
}    

if($userRole == 2 || $userRole == 3){
    $query = "INSERT INTO `inscricao`(`id`,`idCurso`) VALUES('".$_SESSION['id']."', '".$_GET['idCurso']."')"; 
    mysqli_query($GLOBALS['ligacao'], $query);
    echo 'Foi inscrito neste curso';
}
 
dbDisconnect();

?>



