<?php
require_once( "../Lib/lib.php" );
require_once( "../Lib/db.php" );

session_start();
dbConnect(ConfigFile);
$dataBaseName = $GLOBALS['configDataBase']->db;
$serverName = $_SERVER[ 'SERVER_NAME' ];
#$serverName = "localhost";

$serverPort = 80;

$name = webAppName();

$baseUrl = "http://" . $serverName . ":" . $serverPort;

$baseNextUrl = $baseUrl . $name;
mysqli_select_db( $GLOBALS['ligacao'], $dataBaseName );

$errorMsg = "";
$nextUrl = "";

// EMAIL ERROR 
$query = "SELECT `email` FROM `$dataBaseName` . `auth-basic`"; 
$mailError = "";
$queryResult = mysqli_query( $GLOBALS['ligacao'], $query );
$mail = $_POST['email'];
if ($queryResult) {
    while ($registo = mysqli_fetch_array( $queryResult )){
        $email = $registo['email'];
        if($email == $_POST['email']){
            $mailError = "" . '<p>' . "Email já registado! Faça Login" . '</p>';
        }
    }         
}    

//USER ERROR
$query = "SELECT `name` FROM `$dataBaseName` . `auth-basic`"; 
$usernameError = "";
$queryResult = mysqli_query( $GLOBALS['ligacao'], $query );
$user = $_POST['username'];
if ($queryResult) {
    while ($registo = mysqli_fetch_array( $queryResult )){
        $username = $registo['name'];
        if($username == $_POST['username']){
            $usernameError = "Username já existe!";
        }
    }         
}  

// PASSWORD ERROR      
$password1 = $_POST['password1'];
$password2 = $_POST['password2'];
$passError = "";  
if($password1 != $password2){
  $passError = "" . '<p>' . "Passwords não correspondem" . '</p>';  
}   

// CAPTCHA ERROR
$captcha = $_POST['input_captcha'];
$captchaError = '';
if($captcha != $_SESSION['captcha']){
  $captchaError = "" . '<p>' . "Captcha Errado" . '</p>';  
} 

// CRIAR MENSAGEM DE ERRO NA SESSION
$errorMsg = $usernameError . $mailError . $passError . $captchaError; 
$_SESSION['errorMsg'] = $errorMsg;


if(strlen($passError)>0 ||  strlen($usernameError) > 0 || strlen($mailError)>0 || strlen($captchaError) > 0){
    $nextUrl = 'formRegister.php';
    header("Location: " . $baseNextUrl . $nextUrl);   
} else{
    $query = "INSERT INTO `auth-basic`(`name`,`password`,`email`,`valid`) VALUES('".$user."', '".$password1."', '".$mail."', '0')"; 
    mysqli_query($GLOBALS['ligacao'], $query);
    /*******
    $baseNextUrl = $baseUrl . 'Login/' ;
    $nextUrl = 'formLogin.php';
    ********/
    $query = "SELECT `id` FROM `$dataBaseName` . `auth-basic` WHERE `name`= '".$user."'"; 
    $idCriado = 0;
    $queryResult = mysqli_query( $GLOBALS['ligacao'], $query );
    if ($queryResult) {
        while ($registo = mysqli_fetch_array( $queryResult )){
           $idCriado = $registo['id'];
        }         
    } 
    include './challenge.php';
    $query = "INSERT INTO `auth-challenge`(`id`,`challenge`) VALUES('".$idCriado."', '".$challenge."')"; 
    mysqli_query($GLOBALS['ligacao'], $query);
    include './confirmationEmail.php';
    dbDisconnect();     
} 

?>