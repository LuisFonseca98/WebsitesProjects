<?php
require_once( "../Lib/lib.php" );
require_once( "../Lib/db.php" );

dbConnect(ConfigFile);
$dataBaseName = $GLOBALS['configDataBase']->db;
$serverName = $_SERVER[ 'SERVER_NAME' ];
#$serverName = "localhost";

$serverPort = 80;

$name = webAppName();

$baseUrl = "http://" . $serverName . ":" . $serverPort;

$baseNextUrl = $baseUrl . $name;
mysqli_select_db( $GLOBALS['ligacao'], $dataBaseName );



$challenge = htmlspecialchars($_GET["challenge"]);
$col = "ID";
$query = "SELECT count(`id`) as '".$col."' FROM `auth-challenge` where `challenge`='".$challenge."' GROUP by `id`";
$queryResult = mysqli_query( $GLOBALS['ligacao'], $query );
$saida = null;
if ($queryResult) {
    while ($registo = mysqli_fetch_array( $queryResult )){
        $saida = $registo['ID'];
    }         
} 

if(is_null($saida)){
   echo "<h3> LINK Inválido </h3>";
   
}

else{
   echo "<h3>Conta validada! </h3>"; 
   
   $query = "SELECT `id` FROM `auth-challenge` where `challenge` = '".$challenge."'"; 
    $idMudar = 0;
    $queryResult = mysqli_query( $GLOBALS['ligacao'], $query );
    if ($queryResult) {
        while ($registo = mysqli_fetch_array( $queryResult )){
            $idMudar = $registo['id'];
        }         
    } 
   
   $query = "UPDATE `auth-basic` SET valid=1 where id='".$idMudar."'";
   $queryResult = mysqli_query( $GLOBALS['ligacao'], $query );
   
   $query = "DELETE FROM `auth-challenge` WHERE id='".$idMudar."'";
   $queryResult = mysqli_query( $GLOBALS['ligacao'], $query );   
   
    $query = "INSERT INTO `auth-permissions`(`role`,`id`) VALUES(3, '".$idMudar."')"; 
    mysqli_query($GLOBALS['ligacao'], $query);
   
   //ADICIONAR LINK PARA PAG LOGIN
}
//if($challenge)
dbDisconnect();
?>

<head>
  <title>Validar Conta</title>
</head>
