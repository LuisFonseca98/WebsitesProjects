<?php
    require_once( "../Lib/lib.php");
    require_once( "../Lib/lib-mail-v2.php" );
    require_once( "../Lib/HtmlMimeMail-class.php" );
    require_once( "../Lib/db.php" );
    
    $Account = 1;
    $ToName = "";
    $ToEmail = $_POST['email'];
    $Subject = "Validar conta";
    $project = explode('/', $_SERVER['REQUEST_URI'])[2];
    $Message = "Clique no link abaixo para validar a sua conta." .  
            "http://localhost/examples-smi/".$project."/Register/validateRegister.php?challenge=".$_SESSION['$challenge'];  
    $smtpServer = "smtp.gmail.com";
    $mail = new HtmlMimeMail();
    

    
    
    /*
     * HTML component of the e-mail
     */
$MessageHTML = <<<EOD
<html>
    <body style="background: url('background.gif') repeat;">
        <font face="Verdana, Arial" color="#FF0000">
            $Message
        </font>
    </body>
</html>
EOD;
    /*
     * Add the text, html and embedded images.
     */
    $mail->add_html( $MessageHTML, $Message);

    /*
     * Builds the message.
     */
    $mail->build_message();

    /*
     * Sends the message.
     */
    $result = $mail->send(
          $smtpServer,
          1,
          465,
          "iselg13smi@gmail.com",
          "isel1920",
          $ToName, 
          $ToEmail,
          "G13-SMI", 
          "iselg13smi@gmail.com",
          $Subject,
          "X-Mailer: Html Mime Mail Class");

  header("Location: ../Login/formLogin.php");
?>
