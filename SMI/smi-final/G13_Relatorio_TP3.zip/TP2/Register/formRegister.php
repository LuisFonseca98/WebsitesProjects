
<?php
if (!isset($_SESSION)) {
    session_start();
}
$errorMsg = "";

if(isset($_SESSION['errorMsg'])){
    $errorMsg = $_SESSION['errorMsg'];
    $_SESSION['errorMsg'] = '';
}

  $text = "";
  $link = "";
        
  if (isset($_SESSION['username']) ) {
    $text = "Logout";
    $link = "../Login/logout.php";
    }
    else{
        $text = "Login";
        $link = "../Login/processFormLogin.php";
    }
?>

<head>
    <link rel="stylesheet" type="text/css" href="CSS/login.css">
    <link rel="stylesheet" type="text/css" href="CSS/mainPage.css">
    <title>Register</title>
</head>

<ul>
    <?php echo "<li><a href='".$link."'>".$text."</a></li>" ?>;
    <li><a href="../Conteudos/paginaConteudos/conteudosWebsiteCursos.php">Cursos</a></li>
    <li><a href="../About/about.php">About</a></li>
    <li><a href="../PaginaPrincipal/PaginaPrincipal.php">Home</a></li>
</ul>

<div class="cont">
    <form action="processFormRegister.php" method="POST">
        <h3>Register</h3>
        <table>
            <tr>
                <td>User Name</td>
                <td><input 
                    type="text" 
                    name="username"
                    placeholder="User name"
                    required></td>
            </tr>
            <tr>
                <td>Password</td>
                <td><input 
                    type="password" 
                    name="password1"
                    placeholder="Password"
                    required></td>
            </tr>
            <tr>
                <td>Re-type Password:</td>
                <td><input 
                    type="password" 
                    name="password2"
                    placeholder="Password"
                    required></td>
            </tr>     
            <tr>
                <td>Email</td>
                <td><input 
                    type="email" 
                    name="email"
                    placeholder="Email"
                    required></td>
            </tr>  
        </table>
        
        <div style='margin:15px'> 
            <img src="captcha.php" > 
            <input name="input_captcha"type="text" required/>
        </div>

        <input type="submit" value="Register"> <input type="reset" value="Clear">
        <a href="../Login/formLogin.php">Back to Login</a>
        <p><?php echo $errorMsg?></p>    
    </form>
</div>    

