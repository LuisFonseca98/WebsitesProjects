
<?php
require_once( "../Lib/lib.php" );
require_once( "../Lib/db.php" );

// Opens a connection to a MySQL server
if (!isset($_SESSION)) {
    session_start();
}


$_SESSION['locationAfterAdd'] = "AboutPage.php";
dbConnect(ConfigFile);
$dataBaseName = $GLOBALS['configDataBase']->db;
mysqli_select_db( $GLOBALS['ligacao'], $dataBaseName );

$query = "SELECT * FROM googlemaps WHERE 1";

$queryResult = mysqli_query( $GLOBALS['ligacao'], $query );

$text = "";
$link = "";

if (isset($_SESSION['username']) ) {
    $text = "Logout";
    $link = "../Login/logout.php";
}
else{
    $text = "Login";
    $link = "../Login/processFormLogin.php";
}
?>

<link rel="stylesheet" href="cssMain/mainPage.css">
<head>
  <title>About</title>
</head>

<ul id="barra">
    <?php echo "<li class='li'><a href='".$link."'><span class='notranslate'>".$text."</span></a></li>" ?>
    <li class="li"><a href="../Conteudos/paginaConteudos/conteudosWebsiteCursos.php">Cursos</a></li>
    <li class="li"><a class="active" href="../About/about.php"><span class='notranslate'>About</span></a></li>
    <li class="li"><a href="../PaginaPrincipal/PaginaPrincipal.php"><span class='notranslate'>Home</span></a></li>
    <li class="li" <a id="translate"> <div id="google_translate_element"></div></a></li>
</ul>



<h1 id="title"> Acerca dos Autores do Website:</h1>
<h2> Este projeto foi organizado no ambito da disciplina de Sistema de Multimédia e realizado pelos seguintes elementos:</h2>
<p>Miguel Duarte</p>
<ul>
    <li>Contato: 961144452</li>
    <li>Email: mDuarte@gmail.com</li>
    <li>Situação atual: a concluir a licenciatura de Engenharia de Informática e Multimédia(LEIM)</li>
</ul>

<p>Rafael Vitorino</p>
<ul>
    <li>Contato: 918456789</li>
    <li>Email: rVitorino@hotmail.com</li>
    <li>Situação atual: a concluir a licenciatura de Engenharia de Informática e Multimédia(LEIM)</li>
</ul>

<p>Luís Fonseca</p>
<ul>
    <li>Contato: 918789654</li>
    <li>Email: Lfonseca@sapo.pt</li>
    <li>Situação atual: a concluir a licenciatura de Engenharia de Informática e Multimédia(LEIM)</li>
</ul>

Caso tenha interesse em nos visitar, pode ser visto a localização da faculdade na imagem de baixo:
<div id="googleMap" style="width:50%;height:400px;margin-left: 25%;"></div>

<p>Para mais informacções acerca da faculdade, clique na imagem em baixo, ou então selecione a imagem do facebook, caso tenha alguma dúvida!</p>

<div id="isel" class="row">
  <div class="column">
    <a href="https://www.isel.pt/en/">
        <img height="75" src ="images/iselLogo.png"/>
    </a>
    <a href="https://www.facebook.com/isel.pt/">
        <img height="75" style="margin-left: 10%;"src ="images/fbLogo.jpg"/>
    </a>
</div>

<script>
function myMap() {
var mapProp= {
  center:new google.maps.LatLng(38.756107,-9.116923),
  zoom:17,
};
var map = new google.maps.Map(document.getElementById("googleMap"),mapProp);
}
    function googleTranslateElementInit() { 
        new google.translate.TranslateElement({pageLanguage: 'pt', includedLanguages: 'en,es,fr,pt', 
            layout: google.translate.TranslateElement.InlineLayout.SIMPLE},'google_translate_element');
    }


</script>
<script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBHfVOvuyvRGhi41p2KHLbSEbUHPg1buKk&callback=myMap"></script>