<?php

if (!isset($_SESSION)) {
    session_start();
}

$_SESSION['locationAfterAuth'] = "../Conteudos/paginaConteudos/conteudosWebsiteCursos.php";

$text = "";
$link = "";

if (isset($_SESSION['username']) ) {
    $text = "Logout";
    $link = "../Login/logout.php";
}
else{
    $text = "Login";
    $link = "../Login/processFormLogin.php";
}

?>
<link rel="stylesheet" href="cssMain/mainPage.css">
<link rel="stylesheet" href="cssMain/styles.css">
<head>
  <title>Home Page</title>
</head>

<html>
<ul id="barra">
    <?php echo "<li class='li'><a href='".$link."'><span class='notranslate'>".$text."</span></a></li>" ?>
    <li class="li"><a href="../Conteudos/paginaConteudos/conteudosWebsiteCursos.php">Cursos</a></li>
    <li class="li"><a href="../About/about.php"><span class='notranslate'>About</span></a></li>
    <li class="li"><a class="active" href="../PaginaPrincipal/PaginaPrincipal.php"><span class='notranslate'>Home</span></a></li>
    <li class="li" <a id="translate"> <div id="google_translate_element"></div></a></li>
</ul>
<!-- Masthead-->
        <header class="masthead">
            <div class="container h-100">
                <div class="row h-100 align-items-center justify-content-center text-center">
                    <div class="col-lg-10 align-self-end">
                        <h1 class="text-uppercase text-white font-weight-bold">Seja bem vindo à nossa página E-Learning.</h1>
                        <hr class="divider my-4" />
                    </div>
                    <div class="col-lg-8 align-self-baseline">
                        <p class="text-white-75 font-weight-light mb-5">No nosso website poderá encontrar diversos vídeos de tutoriais de diferentes linguagens de programação</p>
        </body>

<script type="text/javascript">
    function googleTranslateElementInit() { 
        new google.translate.TranslateElement({pageLanguage: 'pt', includedLanguages: 'en,es,fr,pt', 
            layout: google.translate.TranslateElement.InlineLayout.SIMPLE},'google_translate_element');
    }
</script>
<script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
<footer class="footer">Trabalho realizado pelo grupo13, da disciplina de Sistemas Multimédia para a Internet </footer>
</html>